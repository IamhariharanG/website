{
    'name': 'DYNAMIC PDF TEMPLATES',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'DYNAMIC PDF TEMPLATES',
    'depends': ['base','mail','sale'],
    'data': [
           'views/template_master.xml',
           'views/sale_inherit.xml',
           'security/ir.model.access.csv',
           'report/view.xml', 
           'report/dynamic_template_pdf.xml', 
            
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
