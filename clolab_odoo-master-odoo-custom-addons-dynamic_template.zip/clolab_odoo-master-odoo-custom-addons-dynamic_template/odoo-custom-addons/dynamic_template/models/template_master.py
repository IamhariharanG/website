from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Dynamictemplate(models.Model):
    _name = 'template.template'
    _rec_name='name'
    _inherit = ['mail.thread','mail.activity.mixin']

    name=fields.Char(string="Template Name",required=True,track_visibility='onchange')
    template=fields.Html(string="Template",required=True,track_visibility='onchange')


        
    
   
        