from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Saleorderinherits(models.Model):
    _inherit="sale.order"

    template_id=fields.Many2one('template.template',string="Template Name")
    templates=fields.Html(string="Template")

        
    @api.constrains('template_id')
    @api.onchange('template_id')
    def _append_templates(self):
        for rec in self:
            if rec.template_id:
                orm = self.env['template.template'].search([('name','=',rec.template_id.name)])
                rec.templates=orm.template

               
    
   
   
   
        