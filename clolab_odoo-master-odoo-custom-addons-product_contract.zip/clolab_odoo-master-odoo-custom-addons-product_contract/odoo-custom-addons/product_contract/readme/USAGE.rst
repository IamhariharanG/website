To use this module, you need to:

#. Go to Sales -> Products and select or create a product.
#. Check "Is a contract" and select the contract template related to the
   product
#. Define default recurrence rules
