* Ted Salmon <tsalmon@laslabs.com>
* Souheil Bejaoui <souheil.bejaoui@acsone.eu>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Ernesto Tejeda
  * Pedro M. Baeza
