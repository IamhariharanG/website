from odoo import api, fields, models 

class hr_wizard(models.TransientModel):
    _name = 'hr.wizard'
    _description = 'HR employee wizard'
    message = fields.Text(string="Document", readonly=True, store=True,default="Document Created Successfully !!!")