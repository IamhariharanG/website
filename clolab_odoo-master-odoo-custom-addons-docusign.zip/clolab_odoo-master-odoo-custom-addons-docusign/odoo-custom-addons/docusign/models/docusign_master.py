from odoo import fields,api,models
from openerp.exceptions import ValidationError
from openerp.exceptions import UserError
import base64
import requests

class DocusignIntegration(models.Model):
    
    _name = 'docusign.master'
    _description = "Docusign Integration"
    _rec_name = 'name'
    _inherit = ['mail.thread','mail.activity.mixin']
    
    name = fields.Char(string="Name",track_visibility='onchange')
    email = fields.Char(string="Email",track_visibility='onchange')
    password = fields.Char(string="Password",track_visibility='onchange')
    account_id = fields.Char(string="Account ID",track_visibility='onchange')
    integration_key = fields.Char(string="Docusign Integration Key",track_visibility='onchange')
    secret_key = fields.Text(string="Secret Key",track_visibility='onchange')
    web_url = fields.Text(string="Token URL",store=True,track_visibility='onchange')
    code = fields.Text(string="Code",track_visibility='onchange')
    access_token = fields.Text(string="Access Token",store=True)
    
    @api.onchange('integration_key')
    def get_url(self):
        if self.integration_key:
            url_insert = f"https://account-d.docusign.com/oauth/auth?response_type=code&scope=signature&client_id={self.integration_key}&redirect_uri=http://localhost/"
            self.web_url = url_insert
    @api.onchange('code')       
    def access_token_gather(self):
        if self.code:
            integration_key = self.integration_key
            secret_key = self.secret_key
            credentials = f'{integration_key}:{secret_key}'
            base64_credentials = base64.b64encode(credentials.encode()).decode()
            headers = {
                    "Authorization": f"Basic {base64_credentials}",
                    "Content-Type": "application/x-www-form-urlencoded"
                }
            token_url = "https://account-d.docusign.com/oauth/token"
            body = {
                'grant_type' : 'authorization_code',
                'code' : self.code
            }
            access_token_url = requests.post(token_url,headers=headers,data=body)
            # raise ValidationError(access_token_url)
            if access_token_url.status_code == 200:
                    access_token_data = access_token_url.json()
                    # access_token = access_token_data.get('access_token')
                    # self.access_token = access_token
                    refresh_token = access_token_data.get('refresh_token')
                    self.access_token = refresh_token
                    # raise ValidationError(refresh_token)
                    # Do something with the access token, such as raising it
            else:
                pass
            # raise ValidationError("Access token request failed.")
# integration_key = 'fb5af452-94a3-4644-9396-506cdbd467e2'
# secret_key = 'cafb02c3-3c84-4a57-8b31-f3333c20a3b8'
# credentials = f'{integration_key}:{secret_key}'
# base64_credentials = base64.b64encode(credentials.encode()).decode()
# print(base64_credentials)