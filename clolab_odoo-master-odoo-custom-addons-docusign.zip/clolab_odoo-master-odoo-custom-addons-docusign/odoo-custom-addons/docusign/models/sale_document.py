from odoo import fields,api,models
from odoo.exceptions import ValidationError
import requests
import json
import base64
import os

class DocusignSaleOrder(models.Model):
    
    _inherit = "sale.order"
    
    docusign_id = fields.Many2one('docusign.master',string="Docusign Account")
    docusign_file = fields.Binary(string="Attachment")
    docusign_attachment = fields.One2many('docusign.attachment.line','attachment_id',string="Docusign Attachment",ondelete="cascade")
    
    
    def button_receive(self):
        base_url = "https://demo.docusign.net/restapi/v2"
        account_id = self.docusign_id.account_id
        # envelope_id = "6d631fa3-aca7-4f79-982f-5add19703d38"
        document_id = "1"
        # access_token = "eyJ0eXAiOiJNVCIsImFsZyI6IlJTMjU2Iiwia2lkIjoiNjgxODVmZjEtNGU1MS00Y2U5LWFmMWMtNjg5ODEyMjAzMzE3In0.AQsAAAABAAUABwCAh4Eze6fbSAgAgMekQb6n20gCAEmYYH8AwAhKiqbR9fG4rBcVAAEAAAAYAAEAAAAFAAAADQAkAAAAZmI1YWY0NTItOTRhMy00NjQ0LTkzOTYtNTA2Y2RiZDQ2N2UyIgAkAAAAZmI1YWY0NTItOTRhMy00NjQ0LTkzOTYtNTA2Y2RiZDQ2N2UyEgABAAAACwAAAGludGVyYWN0aXZlMAAA1Zoke6fbSDcA9BnCBMlG7EWP9FpHf4QGIA.sQxOvV6hOwJJU_K8f2cm5H7Cu1-FpqoDNoaRKggIWH_9MWCLY6BcZ09wcsz82bQfqo6_2VLTB0isvkJLjic9XCgmnQfxtwtDJ0P1Tut9IlZwt58QrUrkh2ZNS_joZ0s09XCJZu0Myh_m2G360uoU63oq7aKSW5qv4DJEG4Rn1fEKYVN34Hwf0HtVhwq-5pzkGwVjD9QFYKLZJISZRzemnkwyRGHZYCwsFq-_89WhvV31Tsg2P6EqCsrRksvfRhUm8lkHDrkqr8kbvraGv1XszVfl8WJ67OD2pPlMKJgh_ziuk0Dask8lxMAPzO_oEthJECgxfFXF5oT9KLumxfGj5w"
        access_token = self.docusign_id.access_token
        for rec in self.docusign_attachment:
            envelope_url = f"{base_url}/accounts/{account_id}/envelopes/{rec.envelope_id}"
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json"
            }

            response = requests.get(envelope_url, headers=headers)
            envelope_info = response.json()
            envelope_status = envelope_info["status"]
            envelope_id = envelope_info["envelopeId"]
            document_url = f"{envelope_url}/documents/{document_id}"
            response = requests.get(document_url, headers=headers, stream=True)

            if response.status_code == 200 and envelope_status == 'completed':
                encoded_pdf_data = base64.b64encode(response.content).decode("utf-8")
                save_ir_attachment = {
                    'name' : "Signed Docusign Document",
                    'type' : 'binary',
                    'datas' : encoded_pdf_data,
                    'store_fname' : encoded_pdf_data,
                    'mimetype' : 'application/pdf',
                }
                store_ir_attachment = self.env['ir.attachment'].create(save_ir_attachment)
                if envelope_id == rec.envelope_id :
                    rec.write({
                        'document_signed_attachment': [(6,0,[store_ir_attachment.id])],
                        'status': envelope_status
                    })
                else:
                    pass
            else:
                pass
        
    def button_send(self):
        integrator_key = self.docusign_id.integration_key
        base_url = "https://demo.docusign.net/restapi/v2"
        account_id =  self.docusign_id.account_id
        # access_token = "eyJ0eXAiOiJNVCIsImFsZyI6IlJTMjU2Iiwia2lkIjoiNjgxODVmZjEtNGU1MS00Y2U5LWFmMWMtNjg5ODEyMjAzMzE3In0.AQsAAAABAAUABwCAh4Eze6fbSAgAgMekQb6n20gCAEmYYH8AwAhKiqbR9fG4rBcVAAEAAAAYAAEAAAAFAAAADQAkAAAAZmI1YWY0NTItOTRhMy00NjQ0LTkzOTYtNTA2Y2RiZDQ2N2UyIgAkAAAAZmI1YWY0NTItOTRhMy00NjQ0LTkzOTYtNTA2Y2RiZDQ2N2UyEgABAAAACwAAAGludGVyYWN0aXZlMAAA1Zoke6fbSDcA9BnCBMlG7EWP9FpHf4QGIA.sQxOvV6hOwJJU_K8f2cm5H7Cu1-FpqoDNoaRKggIWH_9MWCLY6BcZ09wcsz82bQfqo6_2VLTB0isvkJLjic9XCgmnQfxtwtDJ0P1Tut9IlZwt58QrUrkh2ZNS_joZ0s09XCJZu0Myh_m2G360uoU63oq7aKSW5qv4DJEG4Rn1fEKYVN34Hwf0HtVhwq-5pzkGwVjD9QFYKLZJISZRzemnkwyRGHZYCwsFq-_89WhvV31Tsg2P6EqCsrRksvfRhUm8lkHDrkqr8kbvraGv1XszVfl8WJ67OD2pPlMKJgh_ziuk0Dask8lxMAPzO_oEthJECgxfFXF5oT9KLumxfGj5w"
        access_token = self.docusign_id.access_token
        # hi = self.docusign_file
        # base64_encoded = base64.b64encode(hi)
        # base64_encoded_string = base64_encoded.decode('utf-8')
        # raise ValidationError(self.docusign_file)
        # attachment_content = self.docusign_file.read()  # Assuming self.docusign_file is a binary field
        # attachment_base64 = attachment_content.encode("base64").replace("\n", "")
        envelope_payload = {
                "emailSubject": "Please Sign This Document you",
                "documents": [
                                {
                                    "documentId": "1",
                                    "name": "Document.pdf",
                                    "documentBase64": self.docusign_file,
                                }
                        ],
                        "recipients": {
                                    
                            "signers": [
                                {
                                    "emailSubject": "Sign this document",
                                    "email": self.docusign_id.email,
                                    "name": self.docusign_id.name,
                                    "recipientId": "1",
                                    "routingOrder": "1",
                                    "tabs": {
                                        "SignHere": [
                                            {
                                                "anchor_string": "/sn1/",
                                                "anchor_x_offset": "10",
                                                "anchor_y_offset": "20",
                                                "anchor_units": "pixels"
                                            }
                                        ]
                                    }
                                }
                            ]
                        },
                        "status": "sent"
                    }
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }

        # Make the API request
        url = f"{base_url}/accounts/{account_id}/envelopes"
        response = requests.post(url, headers=headers, json=envelope_payload)
        # raise ValidationError(response)
        # # Check the response
        if response.status_code == 201:
            response_json = response.json()  # Parse the JSON response
            envelope_id = response_json.get("envelopeId")
            list1=[]
            ir_values = {
                'name': "Docusign Unsigned",
                'type': 'binary',
                'datas': self.docusign_file,
                'store_fname': self.docusign_file,
                'mimetype': 'application/pdf',
            }
            data_id = self.env['ir.attachment'].create(ir_values)
            # raise ValidationError(data_id.datas)

            data = {
                'document_name': "Docusign Attachment",
                'envelope_id': envelope_id,
                'document_unsigned_attachment': [(4,data_id.id)],
                'status': 'sent',
                'attachment_id': self._origin.id,
            }

            create_orm = self.env['docusign.attachment.line'].create(data)

            return {
                'name': 'Pdf Generation Form',
                'type': 'ir.actions.act_window',
                'res_model': 'hr.wizard',
                'view_mode': 'form',
                'view_type': 'form',
                'target': 'new'
            }
            # print("Envelope ID:",envelope_id)
            # print("Envelope sent successfully!")
        else:
            raise ValidationError("Failed to send envelope")
            # print("Failed to send envelope. Status code:", response.status_code)
            # print("Response:", response.text)
# class DocusignAttachment(models.Model):
    
#     _name = "docusign.attachment.line"
#     _description = "Docusign Attachment Line"
    
#     DOCUMENT_STAUS = [
#         ('sent','Sent'),
#         ('completed','Completed'),
#     ]
    
#     attachment_id_lines = fields.Many2one('agreement',string="Docusign Sale")
#     attachment_id = fields.Many2one('sale.order',string="Docusign Sale")
#     document_name = fields.Char(string="Document Name")
#     envelope_id = fields.Char(string="Envelope ID")
#     # unsigned_attachment_document = fields.Many2many(comodel_name='ir.attachment',relation="docusign_unsign",column1="document_signed",column2="document_unsigned",string="Unsigned Attachment")
#     # signed_attachment_document = fields.Many2many(comodel_name='ir.attachment',relation="docusign_sign",column1="document_signed",column2="document_unsigned",string="Signed Attachment")
    
#     document_unsigned_attachment = fields.Many2many(comodel_name = 'ir.attachment',relation="many2many_unsigned",string="Unsigned Attachment")
#     document_signed_attachment = fields.Many2many(comodel_name = 'ir.attachment',relation="many2many_signed",string="Signed Attachment")
#     status = fields.Selection(DOCUMENT_STAUS,string="Status")

# CSV
# access_hr_wizard_user,Wizard Model,model_hr_wizard,base.group_user,1,1,1,1