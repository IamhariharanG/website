{
    'name' : "Docusign",
    'summary' : "Sending PDF to the Docusign",
    'description' : '''The Uploded PDF has been sended to the user to Docusign''',
    'category' : "Integration",
    'author' : 'Dilip Kumar S',
    'company' : 'Scopex',
    'website' : 'scopex.in',
    'depends' : ['base','sale'],
    'data' : [
        'security/ir.model.access.csv',
        'views/docusign_master.xml',
        'views/sale_document.xml',
        'views/popup.xml',
    ],
   'images':['static/description/icon.png'],
    'version' : '14.0.1.0.0',
    'auto_install' : False,
    'installable' : True,
    'application' : True,
    
}