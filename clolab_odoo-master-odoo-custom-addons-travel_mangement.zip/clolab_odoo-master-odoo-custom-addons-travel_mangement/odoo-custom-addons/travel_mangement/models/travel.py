# -*- coding: utf-8 -*-
from odoo import models,fields,api
class TravelTravel(models.Model):
    
    _name = 'travel.travel'
    _log_access=False

    name=fields.Char(strirng="Name",required=True)
    address=fields.Text(string="Address")
    age=fields.Integer(string="Age")
    sample=fields.Many2one('res.users',string="Sample")
    gender=fields.Selection([('male','Male'),('female','Female'),('others','Others')],string="Gender")
    date=fields.Date(string="Journey Date")
    where=fields.Char(string="From")
    when=fields.Char(string="To")

    @api.model
    def name_create(self,name):
        return self.create({'name':name}).name_get()[0]