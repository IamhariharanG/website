from odoo.exceptions import ValidationError
from odoo import http
from odoo.http import request
import base64 
from odoo.addons.portal.controllers.portal import CustomerPortal


class employee(http.Controller):
# This controller is used to loading the page when you clicking on the menu button.
    @http.route('/website_job',type="http",auth="public",website=True)
    def apply_job(self,**kw):
        return http.request.render('hospital_system_management.application_page',{}) 

    @http.route('/website/page1',type="http",auth="public",website=True)
    def create_new(self,**kw):
        request.env['hr.applicant'].sudo().create(kw)   
        return request.render('hospital_system_management.applied_thanks',{})

    # @http.route('/website/page1',type="http",auth="public",website=True)
    # def applying_jobs(self,**kw):
    #     if request.httprequest.method == 'POST':
    #         task=request.env['hr.applicant'].sudo().create(kw)
    #         if 'res' in request.params:
    #             attach_files=request.httprequest.files.getlist('res')
    #             for attachment in attach_files:
    #                 attach_files=attachment.read()
    #                 request.env['ir.attachment'].sudo().create({
    #                     'name':attachment.filename,
    #                     'res_model':'hr.applicant',
    #                     'res_id':task.id,
    #                     'type':'binary',
    #                     'datas_fname':attachment.filename,
    #                     'datas':attach_files.encode('base64'),
    #                 })
    #     request.env['hr.applicant'].sudo().create(kw)   
    #     return request.render('hospital_system_management.applied_thanks',{})
        # raise ValidationError(self)

       
        # request.env['hr.applicant'].sudo().create(kw)
           
    # @http.route('/website/page1',type="http",auth="public",website=True)
    # def applying_jobs(self,**kw):
    #     res=kw.get('res', False)
    #     name=kw.get('name',False)
    #     request.env['hr.applicant'].sudo().create({
    #         'name':name,
    #         'res':res,
    #     })
    #     request.env['hr.applicant'].sudo().browse(223).write({'weak': type(name)})
    #     return http.request.render('hospital_system_management.applied_thanks',{}) 


# @http.route('/website/page1',type="http",auth="public",website=True)
# def applying_jobs(self,**kw):
#     if kw.get('res', False):
#         attachment_ids = request.env['ir.attachment']
#         name = kw.get('res').filename
#         file = kw.get('res')
#         res = file.read()
#         attachment_ids.sudo().create({
#             'name': name,
#             'res_name': name,
#             'type': 'binary',
#             'res_model': 'ir.attachment',
#             # 'res_id': order.id,
#         })
#     request.env['hr.applicant'].sudo().create(kw)  
#     return http.request.render('hospital_system_management.applied_thanks',{})
            # return request.render("modulename.template_to_render", value)
        # name = kw.get('name')
        # var = {
        #     'name': name,
        #     'type': 'binary', 
        #     'datas':res,
            # 'store_fname': name,

        # 'res_model': self._name,
            # 'res_id':10,
            # 'mimetype': 'application/pdf',
            # 'public': True,
    # }
        # attach = request.env['ir.attachment'].sudo().create(var)
        # if attach:
        #     pdf_id = attach.id
        # request.env['hr.applicant'].sudo().create({'name': name,'res':res})

       



    # def add_attachments(self, **kw):
    #     # order = request.website.sale_get_order()
    #     if kw.get('res', False):
    #         attachment_ids = request.env['ir.attachment']
    #         name = kw.get('res').filename
    #         file = kw.get('res')
    #         res = file.read()
    #         attachment_ids.sudo().create({
    #             'name': name,
    #             'res_name': name,
    #             'type': 'binary',
    #             'res_model': 'ir.attachment',
    #             # 'res_id': order.id,
    #             'datas': base64.b64encode(res),
    #         })
    #  value = {
    #             'attachment' : attachment_id
    #         }
    #   return request.render("modulename.template_to_render", value)

# class employee(http.Controller):
# # This controller is used to loading the page when you clicking on the menu button.
#     @http.route('/website_job',type="http",auth="public",website=True)
#     def apply_job(self,**kw):
#         return http.request.render('hospital_system_management.application_page',{})

                                                                                #THIS CODE IS USED TO TAKE THE MANY2ONE FIELDS TO WEBSITE
                                                                                # job_rec=request.env['hr.job'].sudo().search([])
                                                                                # type_rec=request.env['hr.recruitment.degree'].sudo().search([])
                                                                                #THE FIRST TWO IS MANY2ONE FIELD AND ONE IS USED TO ASSIGN THE DEFAULT FIELD IN WEBSITE TO FIELDS 
                                                                                # return http.request.render('hospital_system_management.application_page',{'job_rec':job_rec,
                                                                                #                                                                              'type_rec':type_rec,
                                                                                #                                                                               'availability':'2002-07-15'})


                                                                                # raise ValidationError("not found")

                                                                                # res_if= request.env['ir.attachment'].sudo().create([('res')])    
                                                                                # res=[[6,True,[2315]]]
                                                                                # raise ValidationError(d)


                                                                                # @http.route('/website/page1',type="http",auth="public",website=True)
                                                                                # def job_page(self,**kw):
                                                                                #     request.env['hr.applicant'].sudo().create(kw)   
                                                                                #     return request.render('hospital_system_management.redirect_page2',{})



    # @http.route('/website/page1',type="http",auth="public",website=True)
    # def job_page(self,**kw):
    #     return request.render('hospital_system_management.redirect_page2',{})


    # @http.route('/website/page2',type="http",auth="public",website=True)
    # def page_job(self,**kw):
    #     return request.render('hospital_system_management.page_redirection',{})

    # @http.route('/website/next',type="http",auth="public",website=True)
    # def create_new(self,**kw):
    #     request.env['hr.applicant'].sudo().create(kw)   
    #     return request.render('hospital_system_management.applied_thanks',{})
    
   
   
   
   
   
   
   
   
   
    # @http.route('/website/next',type="http",auth="public",website=True)
    # def apply_job(self,**kw):
    #     return request.render('hospital_system_management.page_redirection',{})


    # @http.route('/website/next',type="http",auth="public",website=True)
    # def page_job(self,**kw):
    #         return request.render('hospital_system_management.page_redirection',{})


    
    
    # This controller is used to creating the records in the whole back-end in odoo database.
    # @http.route('/create/application',type='http',auth='public',website=True)
    # def create_new(self,**kw):
    #     request.env['hr.applicant'].sudo().create(kw)   
    #     return request.render('hospital_system_management.applied_thanks',{})
   
    
    
    
    # def send_mail(self, cr, uid, ids, context=None, template=""):
    #    for object in self.browse(cr, uid, ids, context=context):
    #         # Check if the parnter has "opt_out" for the mail
    #         if (not object.partner_id.opt_out):
    #             template_id = self.pool.get('email.template').search(cr, uid, [("name","=",template)])
    #             if template_id:
    #                 mail_message = self.pool.get('email.template').send_mail(cr,uid,template_id[0],object.id)
    # this code is used to add the same data in more than one menus in the same model
    # data_adding={
    #     'name': kw.get('partner_name')
    # }
    # request.env['patient.patient'].sudo().create(data_adding)

    # def function(self,**kw):  
    #     fh = open("imageToSave.png", "wb")
    #     fh.write(img_data.decode('base64'))
    #     fh.close()

    # # or, more concisely using with statement
    # with open("imageToSave.png", "wb") as fh:
    #     fh.write(img_data.decode('base64'))
    

# THIS CODE IS USED TO RETRIEVE THE DATA FROM THE ODOO TO THE DATABASE
# from odoo import http
# from odoo.http import request
# class implement(http.Controller):
#     @http.route('/website/steel',type="http",auth="public",website=True)
#     def maintain(self,**kw):
#         patient=request.env['patient.patient'].sudo().search(['state','in',['stage_id',]])
#         collect=request.env['patient.patient'].sudo().search([])
#         # return request.render("hospital_system_management.retrive_data",{
#         #     'patient':patient,
#         #     'collect':collect
#         # })
#         return request.render("hospital_system_management.retrive_data",{
#             'patient':patient,
#             'collect':collect
#         })


# THIS CODE IS USED TO WHEN YOU ENTER INTO THE JOB PORTAL WHAT MUST BE DISPLAY.
# +++++++class Customer(CustomerPortal):
#     @http.route(['/my/job_portal', '/my/job_portal/page/<int:page>'], type='http', auth="user", website=True)
#     def portal_my_job(self, **kw):
#         jobs=http.request.env['hr.applicant'].search([])
#         # partner=request.env['hr.job']
#         # domain=[]

#         # stage=request.env['stage_id']
#         # domain=[]
#         # if date_begin and date_end:
#         #     domain += [('create_date', '>', date_begin), ('create_date', '<=', date_end)]
#         # values.update({
#         #     # 'date': date_begin,
#         #     'partner':partner,
#         #     # 'stage':stage,
#         #     'default_url':'/my/job_portal',
#         # })
#         return request.render("hospital_system_management.portal_job_application",{
#             'jobs':jobs,
#         })

# # page=1,date_begin=None, date_end=None,


# class CustomerPortal(CustomerPortal):

#     def _prepare_home_portal_values(self, counters):
#         values = super()._prepare_home_portal_values(counters)
#         if 'count_job' in counters:
#             values['count_job'] = request.env['hr.applicant'].search_count([])
#             count_job= request.env['hr.applicant'].search_count([])
#             values.update({
#                 'count_job':count_job,
#             })
#         return values

   
        #     ('state', 'in', ['purchase', 'done', 'cancel'])
        # ]) if request.env['purchase.order'].check_access_rights('read', raise_exception=False) else 0
