# -*- coding: utf-8 -*-
{
    'name':'Travel  Management',
    'version':'1.1',
    'category':'Travelling',
    'author':'karnan varma',
    'website':'http://www.karnan.com',
    'company':'honda',
    'maintainer':'rajkumar',
    'summary':'Travel Management Record',
    'description':'Managing the customer',
    'depends':['base','recruitment'],
    'data':[
            'security/ir.model.access.csv',
            'views/travel_views.xml',            
    ],
  'qweb': [],
  "license": "AGPL-3",
  'installable': True,
  'auto_install': False,
}
