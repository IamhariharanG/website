from odoo import models,fields,api
from datetime import datetime
#from odoo.exceptions import ValidationError

class appoint(models.Model):
    _name="patient.appointment"
    _rec_name="patient"
    _description="Patient Appointment"
            

    #patient=fields.Many2one('res.users',string="Patient Name")
    #date=fields.Datetime(string="Appointment Date")
    
    #(we can also use for "patient") default=lambda self:self.env.user.id   
                                #(or)
    #(use)default=lambda self:self.env.uid
    
    #generating the sequence number.
    name=fields.Char(string="Appointment Number",readonly=True,copy=False,required=True,default='New')



    patient=fields.Many2one('res.users', string='User', default=lambda self: self.env.user)
    doctor=fields.Many2one('res.users',string="Doctor Name")
    date=fields.Datetime(string='Appointment Date',default=lambda self: fields.datetime.now())
    appointment=fields.Boolean(string="Appointment")
    # to create the multiple records use the @api.model_create_multi
    #in pycharm the following code is created in the terminal process
    '''patient=[{'name':'Naruto'},{'name':'Hinata'}]
       result=self.env['patient.appointment'].create(patient)
       result(type this and press Enter)
       op: patient.appointment(49,50) {49,50 is the id name}'''

    @api.model
    def create(self,vals):
        if vals.get('name','New')=='New':
            vals['name']=self.env['ir.sequence'].next_by_code('patient.sequence.number')or'New'
            result=super(appoint,self).create(vals)
            #raise ValidationError(self)
            return result

    def write(self,vals):
        ret=super(appoint,self).write(vals)
        #raise ValidationError(vals)
        return ret