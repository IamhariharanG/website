from odoo import fields,models,api
from datetime import datetime
from odoo.exceptions import ValidationError


AVAILABLE_PRIORITIES = [
    ('0', 'Poor'),
    ('1', 'Normal'),
    ('2', 'Good'),
    ('3', 'Very Good'),
    ('4','Excellent'),
    ('5','Wonderful')
]
class inherit(models.Model):

    _inherit="hr.applicant"
    # res=fields.Many2many('ir.attachment',string="Resume")
    # res=fields.Binary(string="Resume")
    res= fields.Many2many(comodel_name="ir.attachment", 
                                relation="m2m_resume", 
                                column1="m2m_id",
                                column2="attachment_id",
                                string="Resume")
    vacancy=fields.Integer(string="No of Vacancies")


    client=fields.Many2one('hr.job',string="Client Id")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('others', 'Others')], string='Gender')
    dob=fields.Date(string="DOB")
    whats=fields.Char(string="Whatsapp Number")
    address=fields.Text(string="Address")


    h_qualification=fields.Many2one('hr.recruitment.degree',string="Highest Qualification")
    r_qualification=fields.Text(string="Related Qualification")
    location=fields.Char(string="Location Preference")
    strength=fields.Text(string="Strength")
    weak=fields.Text(string="Weakness")
    
    # other=fields.Binary(string="Other Certification")

    other =fields.Many2many(comodel_name="ir.attachment", relation="m2m_other", 
                                column1="m2m_id", column2="attachment_id",string="Other Certification")

     
    
    go_abroad=fields.Selection([('yes','Yes'),('no','No')],string="Willing to go Abroad")
    port=fields.Selection([('yes','Yes'),('no','No')],string="Passport Available")
    pass_number=fields.Char(string="Passport Number")
    
    exp=fields.Selection(string="Experience",selection=[('experience', 'Experience'), ('fresher', 'Fresher')])
    # field1 = fields.Char(string="Company Name")
    # field2 = fields.Date(string='From')
    # field3 = fields.Date(string='To')
    # field4 = fields.Char(string="Years of Experience")
    last=fields.Float(string="Last Drawn Salary")
    
    net=fields.Integer(string="Net Experience")
    information=fields.One2many('hr.applicant.lines','detail',string="Experience Details")
    message = fields.Selection(AVAILABLE_PRIORITIES, "Candidate Rating", default='0') 

    @api.onchange('information')
    def total_exp(self):
        val=[]
        for k in self:
            for n in k.information:
                val.append(n.years)
                k.net = sum(val) 
    
        #     res = {'warning': {
        #         'title': ('Warning'),
        #         'message': ('My warning message.')
        #     }}
     
        # return res

    # @api.onchange('information')
    # def total_exp(self):
    #     val=[]
    #     for k in self:
    #         for n in k.information:
    #             val.append(n.years)
    #             # k.net = sum(val)
    #             a=sum(val)
    #     k.net = a/365 +'months'
    
   

class candidate_exp(models.Model):
    
    _name='hr.applicant.lines'
    _description='Appointment Lines'
    
    detail=fields.Many2one('hr.applicant',string="Candidate")

    comp_name=fields.Char(string="Company Name")
    role=fields.Char(string="Recent Role in The Company")
    change=fields.Char(string="Reason For Change")  
    from_field=fields.Date(string="From")
    to_field=fields.Date(string="To")
    years=fields.Integer(string="Experience")




   
    @api.onchange('from_field', 'to_field','years')
    def calculate_date(self):
        if self.from_field and self.to_field:
            d1=datetime.strptime(str(self.from_field),'%Y-%m-%d') 
            d2=datetime.strptime(str(self.to_field),'%Y-%m-%d')
            d3=d2-d1
            self.years=str(d3.days)
    
    # @api.constrains('from_field', 'to_field','years')
    # def _date_difference(self):
    #     for record in self:
    #             k = (record.to_field - record.from_field).days
    
    # @api.depends('information')
    # def _amount_all(self):
    #     for order in self:
    #         net = 0.0
    #         for line in order.information:
    #             net += line.years
    #         order.update({
    #             'net': net,
    #         })





class job_position(models.Model):
    _inherit="hr.job"
     
    client=fields.Char(string="Client Id")
    target=fields.Date(string="Target Date")


class inbulit(models.Model):
    _inherit='hr.applicant'

    @api.onchange('stage_id')
    def onchange_template_id(self):
        return {'value':{},'warning':{'title':'warning','message':'The Stage of the Record is Changed'}}