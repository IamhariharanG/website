# -*- coding: utf-8 -*-
from odoo import models,fields
class PatientPatient(models.Model):
    
    _name='patient.patient'
    _description='Appointment'
#required=True {this means the name must be entered ie. compulsary the name must be entered}   
    
    name=fields.Char(string="Patient Name",required=True)
    names=fields.Char(string="Doctor Name")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('others', 'Others')], string='Gender')
    appointment_date=fields.Datetime(string="Appointment Date")
    appointment=fields.Char(string="Appointment Detail")
    age=fields.Integer(string="Age")
    height=fields.Float(string="Height")
    weight=fields.Float(string="Weight")
    # fee=fields.Char(string="Doctor Fee",default="1000")
    fee=fields.Char(string="Doctor Fee")
    settlement=fields.Boolean(string="Settlement")
    vitals=fields.Char(string="Vitals")
    instr=fields.Char(string="Instructions")
    notes=fields.Text(string="Notes")
    company=fields.Char(string="Company")
    lab=fields.Boolean(string="Lab Consultation Required")
    #attach=fields.Many2many(string="Attachment",help="This is the Flower Image")
    attach=fields.Many2many('ir.attachment',string="Attachment")
    image=fields.Image(string="Image")
    tax=fields.Many2many('account.tax',string="Tax")
    
    appointment_lines=fields.One2many('patient.patient.lines','detail',string="Appointment Lines")
    partner_id=fields.Many2one('res.partner',string="Partner")
    tag_id=fields.Many2many('travel.travel',string="Tags")
    
class PatientPatientName(models.Model):
    
    _name='patient.patient.lines'
    _description='Appointment Lines'
    
    detail=fields.Many2one('patient.patient',string="patients")
    medicine=fields.Char(string="Medicine")
    instrut=fields.Char(string="Instruction")
    time=fields.Date(string='Time Slots')
    dosage=fields.Integer(string="Dosage")
    quantity=fields.Float(string="Quantity")
    duration=fields.Char(string="Duration")
    notes=fields.Char(string="Notes")
    app=fields.Datetime(string="Appointment Detail")
    medicaldescr=fields.Char(string="Medical Description")   


