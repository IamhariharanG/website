from . import patient
from . import sale
from . import doctor
from . import notes
from . import appointment
from . import inherit