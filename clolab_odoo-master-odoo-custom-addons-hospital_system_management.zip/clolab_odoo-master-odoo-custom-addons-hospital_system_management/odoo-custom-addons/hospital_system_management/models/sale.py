from odoo import api,fields,models

class sales(models.Model):
    _inherit="sale.order"
    tags=fields.Many2many("account.tax",string="Tax")