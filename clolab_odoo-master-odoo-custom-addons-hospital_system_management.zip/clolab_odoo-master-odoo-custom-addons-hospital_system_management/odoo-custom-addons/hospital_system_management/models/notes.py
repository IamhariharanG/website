from odoo import models,fields

class notes(models.Model):

    _name="notes.notes"
    _description="creating of notes"

    name=fields.Char(string="Patient Name",required=True)
    dname=fields.Many2one('res.users',string="Doctor Name")
    notes=fields.Char(string="Notes")