from odoo import models,fields

class doctor(models.Model):

    _name="doctor.doctor"
    _rec_name="pname"
    _description='Patients Doctor'

    pname=fields.Char(string="Patient Name")
    dname=fields.Many2one('res.users',string="Doctor Name")