$(document).on('click', '.row-add', function() {
    console.log('a')
    var $tr = $(this).closest('.tr_clone');
    var $clone = $tr.clone();
    console.log($clone);
    $clone.find(':text').val('');
    $tr.after($clone);
});

$(document).on('click','.del-row',function(){
    var tbl=$('#exp_tbl >tbody >tr').length;
    console.log(tbl)
    if (tbl > 1){
        $(this).closest('tr').remove()
    }
    
})
/opt/inventory14/odoo-custom-addons/hospital_system_management/static/src/website.js
       
        // console.log(x.rowIndex)
    //     // var row = table.deleteRow(rowCount-1);
    //     document.getElementById("exp_tbl").deleteRow(0);
    // }
// }

